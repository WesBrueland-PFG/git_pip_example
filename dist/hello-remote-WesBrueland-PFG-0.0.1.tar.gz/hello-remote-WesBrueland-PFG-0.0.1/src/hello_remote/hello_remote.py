def hello():
    print("Hello remote world!")
